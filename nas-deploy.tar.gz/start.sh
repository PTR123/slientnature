#!/bin/bash
set -e

echo "🚀 PetKeeper 后端部署"
echo "====================="

# 检查 Docker
if ! command -v docker &>/dev/null; then
    echo "❌ Docker 未安装"
    exit 1
fi

# 检查 docker-compose
if command -v docker-compose &>/dev/null; then
    COMPOSE="docker-compose"
elif docker compose version &>/dev/null; then
    COMPOSE="docker compose"
else
    echo "❌ Docker Compose 未安装"
    exit 1
fi

echo "✅ Docker: $(docker --version)"
echo "✅ Compose: $COMPOSE"
echo ""

# 停止旧服务
$COMPOSE down 2>/dev/null || true

# 构建并启动
echo "🏗️  构建镜像..."
$COMPOSE build

echo "🚀 启动服务..."
$COMPOSE up -d

echo "⏳ 等待服务启动..."
sleep 30

# 数据库迁移
echo "📊 运行数据库迁移..."
$COMPOSE exec -T backend npx prisma migrate deploy || echo "⚠️  迁移需要检查"

# 状态
echo ""
echo "📊 服务状态:"
$COMPOSE ps

echo ""
echo "✅ 部署完成!"
echo "   API: http://localhost:3001"
