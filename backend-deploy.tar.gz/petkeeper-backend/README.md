# PetKeeper后端部署包

## 文件结构
- docker-compose-backend.yml - 后端服务编排配置
- pet-keeper-backend/ - 后端API代码
- nginx/ - Nginx反向代理配置
- .env - 环境变量配置(需修改)
- docs/ - 部署文档

## 快速部署步骤

1. 修改环境变量:
   vim .env
   # 修改CORS_ORIGIN为你的Vercel前端域名
   # CORS_ORIGIN=https://your-app.vercel.app

2. 启动服务:
   docker-compose -f docker-compose-backend.yml up -d --build

3. 初始化数据库:
   docker-compose -f docker-compose-backend.yml exec backend npx prisma migrate deploy
   docker-compose -f docker-compose-backend.yml exec backend npm run db:seed

4. 测试API:
   curl http://localhost:3001/api/health

5. 查看日志:
   docker-compose -f docker-compose-backend.yml logs -f

详细步骤请参考: docs/SPLIT_DEPLOYMENT_GUIDE.md
